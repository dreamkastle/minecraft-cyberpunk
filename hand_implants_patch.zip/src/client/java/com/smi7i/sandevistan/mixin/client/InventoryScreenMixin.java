package com.smi7i.sandevistan.mixin.client;

import com.smi7i.sandevistan.HandImplantSlot;
import com.smi7i.sandevistan.ImplantSlot;
import com.smi7i.sandevistan.client.ImplantSlotUi;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Голографическое окошко слота импланта в обычном инвентаре (слот 46, позиция 77, 44). */
@Mixin(InventoryScreen.class)
public abstract class InventoryScreenMixin {
    @Inject(method = "extractBackground", at = @At("TAIL"))
    private void sandevistan$frame(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a, CallbackInfo ci) {
        AbstractContainerScreenAccessor acc = (AbstractContainerScreenAccessor) (Object) this;
        Minecraft mc = Minecraft.getInstance();
        boolean filled = mc.player != null && mc.player.inventoryMenu.slots.size() > ImplantSlot.MENU_INDEX
                && mc.player.inventoryMenu.getSlot(ImplantSlot.MENU_INDEX).hasItem();
        ImplantSlotUi.draw(graphics, acc.sandevistan$getLeftPos() + 76, acc.sandevistan$getTopPos() + 43,
                filled, System.currentTimeMillis());
        // Два слота имплантов рук: над слотом Сандевистана (77, 26) и (77, 8).
        int[] handIndex = {HandImplantSlot.MENU_INDEX_1, HandImplantSlot.MENU_INDEX_2};
        int[] handY = {25, 7};
        for (int i = 0; i < 2; i++) {
            boolean handFilled = mc.player != null && mc.player.inventoryMenu.slots.size() > handIndex[i]
                    && mc.player.inventoryMenu.getSlot(handIndex[i]).hasItem();
            ImplantSlotUi.draw(graphics, acc.sandevistan$getLeftPos() + 76, acc.sandevistan$getTopPos() + handY[i],
                    handFilled, System.currentTimeMillis(), true);
        }
    }
}
